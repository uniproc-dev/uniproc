# Shared SVG source at different sizes

On Windows, run `cargo run --locked`. After five seconds compare the top shared-source row and bottom independent-source row at 192 DIP. The window stays open.

The 24 DIP source is displayed first, then shared across 24, 48, 96 and 192 DIP controls. A fresh process with `SVG_LARGE_FIRST=1` uses 192 DIP for the initial display instead. Clear that environment variable for the default test.

See ISSUE.md for the report and evidence/. No Guinea checkout, WinUI metadata checkout, service, native capture or probe button is needed. The dependencies are published preview packages, pinned in Cargo.lock.
