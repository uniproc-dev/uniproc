# Shared SVG source at different sizes

On Windows, run `cargo run --locked`. Both rows appear immediately. Compare the top shared-source row and bottom independent-source row at 192 DIP: both are blurry in this initial-mount variant. The window stays open.

The source is shared across 24, 48, 96 and 192 DIP controls. Independent byte allocations are used in the bottom row. There is no prewarm stage, timer or environment switch. Earlier evidence from a delayed-mount comparison is labeled separately in ISSUE.md.

See ISSUE.md for the report and evidence/. No Guinea checkout, WinUI metadata checkout, service, native capture or probe button is needed. The dependencies are published preview packages, pinned in Cargo.lock.
