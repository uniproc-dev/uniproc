# Shared SVG source at different sizes

On Windows, run `cargo run --locked`. Shared and Independent appear immediately; After 2 updates is created and mounted on the second queued component update. Compare all three rows at 192 DIP. The window stays open.

The source is shared across 24, 48, 96 and 192 DIP controls in the first row. Independent byte allocations are used in the other two rows. There is no prewarm stage or environment switch. Earlier evidence from initial and delayed-mount comparisons is labeled separately in ISSUE.md; it predates the two-update row.

See ISSUE.md for the report and evidence/. No Guinea checkout, WinUI metadata checkout, service, native capture or probe button is needed. The dependencies are published preview packages, pinned in Cargo.lock.

The current visual reproduction also includes a fourth row, After 5 seconds: independent SVG sources are created and mounted by a one-shot five-second timer. The existing queued-update row is retained. Earlier pixel measurements predate this fourth row.
