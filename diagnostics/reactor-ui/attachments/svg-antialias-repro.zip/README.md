# SVG automatic versus explicit raster dimensions

On Windows, configure WinUI metadata and run:

```powershell
$env:WINUI_WINMD = '<windows-rs>/crates/tools/reactor/winmd'
cargo run --locked
```

Use metadata from snapshot 2c6ce7a1edaefb6e585aa3fb112617d1d8211392, matching windows-reactor-pre 0.106.0. Older trees use crates/tools/reactor-metadata/winmd. The package uses published preview dependencies pinned in Cargo.lock; it does not build Reactor from that checkout.

After one second, four labeled images appear. Compare the circle and diagonal in Reactor auto, Native auto, Native raster 192 and Native raster 384. Every Image has a 192 DIP layout size. Native raster properties are set before loading; stderr reports the three load results.

The window stays open, does not capture pixels or close automatically, and has no focus instrumentation or probe buttons. No Guinea checkout or application service is required.

See ISSUE.md and evidence/. The evidence images came from a separate instrumented control, not this visual program.
